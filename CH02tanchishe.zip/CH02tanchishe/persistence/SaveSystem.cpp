#ifndef SNAKEGAME_PERSISTENCE_SAVESYSTEM_CPP_INCLUDED
#define SNAKEGAME_PERSISTENCE_SAVESYSTEM_CPP_INCLUDED

#include "core/StateMachine.cpp"
#include "gameplay/Snake.cpp"
#include "systems/TimeSystem.cpp"

#include <string>
#include <vector>

struct GameSnapshot
{
    int width = 0;
    int height = 0;
    int score = 0;
    int highScore = 0;
    GameState state = GameState::Menu;
    SpeedLevel speedLevel = SpeedLevel::Medium;
    Direction direction = Direction::Stop;
    Point food{ 0, 0 };
    std::vector<Point> snake;
};

class SaveSystem
{
public:
    SaveSystem(std::string highScorePath = "highscore.dat", std::string gameSavePath = "game_save.txt");

    int LoadHighScore() const;
    void SaveHighScore(int highScore) const;

    bool SaveGame(const GameSnapshot& snapshot) const;
    bool LoadGame(GameSnapshot& snapshot) const;

private:
    std::string highScoreFilePath_;
    std::string gameSaveFilePath_;
};

#include <fstream>
#include <utility>

namespace
{
std::string Trim(const std::string& text)
{
    std::size_t begin = 0;
    while (begin < text.size() && (text[begin] == ' ' || text[begin] == '\t' || text[begin] == '\r' || text[begin] == '\n'))
        ++begin;

    std::size_t end = text.size();
    while (end > begin && (text[end - 1] == ' ' || text[end - 1] == '\t' || text[end - 1] == '\r' || text[end - 1] == '\n'))
        --end;

    return text.substr(begin, end - begin);
}

bool ParseInt(const std::string& text, int& value)
{
    const std::string trimmed = Trim(text);
    if (trimmed.empty())
        return false;

    std::size_t index = 0;
    try
    {
        value = std::stoi(trimmed, &index);
    }
    catch (...)
    {
        return false;
    }

    return index == trimmed.size();
}

bool ParsePoint(const std::string& text, Point& point)
{
    const std::string trimmed = Trim(text);
    const std::size_t commaPos = trimmed.find(',');
    if (commaPos == std::string::npos)
        return false;

    int x = 0;
    int y = 0;
    if (!ParseInt(trimmed.substr(0, commaPos), x))
        return false;
    if (!ParseInt(trimmed.substr(commaPos + 1), y))
        return false;

    point.x = x;
    point.y = y;
    return true;
}
}

SaveSystem::SaveSystem(std::string highScorePath, std::string gameSavePath)
    : highScoreFilePath_(std::move(highScorePath)),
      gameSaveFilePath_(std::move(gameSavePath))
{
}

int SaveSystem::LoadHighScore() const
{
    std::ifstream in(highScoreFilePath_);
    int highScore = 0;
    if (in)
        in >> highScore;
    return highScore;
}

void SaveSystem::SaveHighScore(int highScore) const
{
    std::ofstream out(highScoreFilePath_, std::ios::trunc);
    if (out)
        out << highScore;
}

bool SaveSystem::SaveGame(const GameSnapshot& snapshot) const
{
    std::ofstream out(gameSaveFilePath_, std::ios::trunc);
    if (!out)
        return false;

    out << "score=" << snapshot.score << '\n';
    out << "high=" << snapshot.highScore << '\n';
    out << "state=" << static_cast<int>(snapshot.state) << '\n';
    out << "speed=" << static_cast<int>(snapshot.speedLevel) << '\n';
    out << "dir=" << static_cast<int>(snapshot.direction) << '\n';
    out << "size=" << snapshot.width << ',' << snapshot.height << '\n';

    out << "snake=";
    for (std::size_t i = 0; i < snapshot.snake.size(); ++i)
    {
        if (i > 0)
            out << ';';
        out << snapshot.snake[i].x << ',' << snapshot.snake[i].y;
    }
    out << '\n';

    out << "food=" << snapshot.food.x << ',' << snapshot.food.y << '\n';

    return static_cast<bool>(out);
}

bool SaveSystem::LoadGame(GameSnapshot& snapshot) const
{
    std::ifstream in(gameSaveFilePath_);
    if (!in)
        return false;

    bool hasScore = false;
    bool hasDirection = false;
    bool hasSnake = false;
    bool hasFood = false;
    bool hasSize = false;

    snapshot = GameSnapshot{};

    std::string line;
    while (std::getline(in, line))
    {
        const std::string trimmedLine = Trim(line);
        if (trimmedLine.empty())
            continue;

        const std::size_t equalPos = trimmedLine.find('=');
        if (equalPos == std::string::npos)
            continue;

        const std::string key = Trim(trimmedLine.substr(0, equalPos));
        const std::string value = Trim(trimmedLine.substr(equalPos + 1));

        if (key == "score")
        {
            if (!ParseInt(value, snapshot.score))
                return false;
            hasScore = true;
            continue;
        }

        if (key == "high")
        {
            if (!ParseInt(value, snapshot.highScore))
                return false;
            continue;
        }

        if (key == "state")
        {
            int raw = 0;
            if (!ParseInt(value, raw))
                return false;
            if (raw < static_cast<int>(GameState::Menu) || raw > static_cast<int>(GameState::Exit))
                return false;
            snapshot.state = static_cast<GameState>(raw);
            continue;
        }

        if (key == "speed")
        {
            int raw = 0;
            if (!ParseInt(value, raw))
                return false;
            if (raw < static_cast<int>(SpeedLevel::Low) || raw > static_cast<int>(SpeedLevel::High))
                return false;
            snapshot.speedLevel = static_cast<SpeedLevel>(raw);
            continue;
        }

        if (key == "dir")
        {
            int raw = 0;
            if (!ParseInt(value, raw))
                return false;
            if (raw < static_cast<int>(Direction::Stop) || raw > static_cast<int>(Direction::Down))
                return false;
            snapshot.direction = static_cast<Direction>(raw);
            hasDirection = true;
            continue;
        }

        if (key == "size")
        {
            Point sizePoint{};
            if (!ParsePoint(value, sizePoint))
                return false;
            snapshot.width = sizePoint.x;
            snapshot.height = sizePoint.y;
            hasSize = true;
            continue;
        }

        if (key == "snake")
        {
            snapshot.snake.clear();
            std::size_t start = 0;
            while (start < value.size())
            {
                const std::size_t semicolonPos = value.find(';', start);
                const std::string token = value.substr(start, semicolonPos == std::string::npos ? std::string::npos : semicolonPos - start);
                Point point{};
                if (!ParsePoint(token, point))
                    return false;
                snapshot.snake.push_back(point);

                if (semicolonPos == std::string::npos)
                    break;
                start = semicolonPos + 1;
            }

            if (snapshot.snake.empty())
                return false;

            hasSnake = true;
            continue;
        }

        if (key == "food")
        {
            if (!ParsePoint(value, snapshot.food))
                return false;
            hasFood = true;
            continue;
        }
    }

    return hasScore && hasDirection && hasSnake && hasFood && hasSize;
}

#endif
