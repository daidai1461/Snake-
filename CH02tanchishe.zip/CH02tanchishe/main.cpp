#include "core/GameLoop.cpp"

int main()
{
	constexpr int kBoardWidth = 40;
	constexpr int kBoardHeight = 20;

	GameLoop gameLoop(kBoardWidth, kBoardHeight);
	gameLoop.Run();
	return 0;
}
