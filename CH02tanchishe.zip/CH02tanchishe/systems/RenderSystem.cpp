#ifndef SNAKEGAME_SYSTEMS_RENDERSYSTEM_CPP_INCLUDED
#define SNAKEGAME_SYSTEMS_RENDERSYSTEM_CPP_INCLUDED

#include "core/StateMachine.cpp"
#include "gameplay/Food.cpp"
#include "gameplay/Snake.cpp"
#include "systems/TimeSystem.cpp"

#include <windows.h>

struct RenderData
{
    int boardWidth = 0;
    int boardHeight = 0;
    int score = 0;
    int highScore = 0;
    GameState state = GameState::Menu;
    SpeedLevel speedLevel = SpeedLevel::Medium;
    const Snake* snake = nullptr;
    const Food* food = nullptr;
};

class RenderSystem
{
public:
    RenderSystem(int boardWidth, int boardHeight);
    ~RenderSystem();

    bool Initialize();
    void Render(const RenderData& data);

private:
    void Cleanup();
    void PutChar(CHAR_INFO* frame, int x, int y, wchar_t ch, WORD color) const;
    void PutText(CHAR_INFO* frame, int x, int y, const wchar_t* text, WORD color) const;
    const wchar_t* StateText(GameState state) const;
    const wchar_t* SpeedText(SpeedLevel speed) const;

    int boardWidth_;
    int boardHeight_;
    int panelWidth_;
    int screenWidth_;
    int screenHeight_;

    HANDLE buffers_[2];
    HANDLE originalConsole_;
    int frontBufferIndex_;
};

#include <string>
#include <vector>

namespace
{
const WORD COLOR_BORDER = 14;
const WORD COLOR_SNAKE = 10;
const WORD COLOR_FOOD = 12;
const WORD COLOR_DEFAULT = 7;
}

RenderSystem::RenderSystem(int boardWidth, int boardHeight)
    : boardWidth_(boardWidth),
      boardHeight_(boardHeight),
      panelWidth_(42),
      screenWidth_(boardWidth + 2 + 2 + panelWidth_),
      screenHeight_(boardHeight + 2),
      buffers_{ INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE },
      originalConsole_(INVALID_HANDLE_VALUE),
      frontBufferIndex_(0)
{
}

RenderSystem::~RenderSystem()
{
    Cleanup();
}

bool RenderSystem::Initialize()
{
    originalConsole_ = GetStdHandle(STD_OUTPUT_HANDLE);

    for (int i = 0; i < 2; ++i)
    {
        buffers_[i] = CreateConsoleScreenBuffer(
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            CONSOLE_TEXTMODE_BUFFER,
            NULL);

        if (buffers_[i] == INVALID_HANDLE_VALUE)
            return false;

        COORD size = { static_cast<SHORT>(screenWidth_), static_cast<SHORT>(screenHeight_) };
        SetConsoleScreenBufferSize(buffers_[i], size);

        SMALL_RECT rect = {
            0,
            0,
            static_cast<SHORT>(screenWidth_ - 1),
            static_cast<SHORT>(screenHeight_ - 1)
        };
        SetConsoleWindowInfo(buffers_[i], TRUE, &rect);

        CONSOLE_CURSOR_INFO cursorInfo;
        cursorInfo.bVisible = FALSE;
        cursorInfo.dwSize = 1;
        SetConsoleCursorInfo(buffers_[i], &cursorInfo);
    }

    SetConsoleActiveScreenBuffer(buffers_[frontBufferIndex_]);
    return true;
}

void RenderSystem::Render(const RenderData& data)
{
    if (data.snake == nullptr || data.food == nullptr)
        return;

    const int backBufferIndex = 1 - frontBufferIndex_;
    HANDLE backBuffer = buffers_[backBufferIndex];

    std::vector<CHAR_INFO> frame(screenWidth_ * screenHeight_);
    for (CHAR_INFO& pixel : frame)
    {
        pixel.Char.UnicodeChar = L' ';
        pixel.Attributes = COLOR_DEFAULT;
    }

    for (int x = 0; x < boardWidth_ + 2; ++x)
    {
        PutChar(frame.data(), x, 0, L'#', COLOR_BORDER);
        PutChar(frame.data(), x, boardHeight_ + 1, L'#', COLOR_BORDER);
    }

    for (int y = 0; y < boardHeight_ + 2; ++y)
        PutChar(frame.data(), boardWidth_ + 2, y, L'|', COLOR_BORDER);

    const Snake& snake = *data.snake;
    const Food& food = *data.food;

    for (int y = 0; y < boardHeight_; ++y)
    {
        PutChar(frame.data(), 0, y + 1, L'#', COLOR_BORDER);
        PutChar(frame.data(), boardWidth_ + 1, y + 1, L'#', COLOR_BORDER);
    }

    for (const Point& segment : snake.GetTail())
        PutChar(frame.data(), segment.x + 1, segment.y + 1, L'o', COLOR_SNAKE);

    PutChar(frame.data(), food.GetPosition().x + 1, food.GetPosition().y + 1, L'F', COLOR_FOOD);
    PutChar(frame.data(), snake.GetHead().x + 1, snake.GetHead().y + 1, L'O', COLOR_SNAKE);

    const int panelX = boardWidth_ + 4;

    const std::wstring scoreText = L"分数：" + std::to_wstring(data.score);
    const std::wstring highText = L"最高分：" + std::to_wstring(data.highScore);
    const std::wstring stateText = std::wstring(L"状态：") + StateText(data.state);
    const std::wstring speedText = std::wstring(L"速度：") + SpeedText(data.speedLevel);

    PutText(frame.data(), panelX, 1, scoreText.c_str(), COLOR_DEFAULT);
    PutText(frame.data(), panelX, 2, highText.c_str(), COLOR_DEFAULT);
    PutText(frame.data(), panelX, 3, stateText.c_str(), COLOR_DEFAULT);
    PutText(frame.data(), panelX, 4, speedText.c_str(), COLOR_DEFAULT);

    PutText(frame.data(), panelX, 6, L"操作说明：", COLOR_BORDER);
    PutText(frame.data(), panelX, 7, L"WASD 移动", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 8, L"P 暂停/继续", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 9, L"K 保存，L 读取", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 10, L"1/2/3 切换低/中/高速度", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 11, L"空格/回车 开始", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 12, L"X 退出", COLOR_DEFAULT);

    PutText(frame.data(), panelX, 13, L"状态流转：", COLOR_BORDER);
    PutText(frame.data(), panelX, 14, L"菜单 -> 运行中 ->", COLOR_DEFAULT);
    PutText(frame.data(), panelX, 15, L"暂停 -> 游戏结束", COLOR_DEFAULT);

    COORD bufferSize = { static_cast<SHORT>(screenWidth_), static_cast<SHORT>(screenHeight_) };
    COORD bufferCoord = { 0, 0 };
    SMALL_RECT writeRegion = {
        0,
        0,
        static_cast<SHORT>(screenWidth_ - 1),
        static_cast<SHORT>(screenHeight_ - 1)
    };

    WriteConsoleOutputW(backBuffer, frame.data(), bufferSize, bufferCoord, &writeRegion);
    SetConsoleActiveScreenBuffer(backBuffer);
    frontBufferIndex_ = backBufferIndex;
}

void RenderSystem::Cleanup()
{
    if (originalConsole_ != INVALID_HANDLE_VALUE)
        SetConsoleActiveScreenBuffer(originalConsole_);

    for (HANDLE& buffer : buffers_)
    {
        if (buffer != INVALID_HANDLE_VALUE)
        {
            CloseHandle(buffer);
            buffer = INVALID_HANDLE_VALUE;
        }
    }
}

void RenderSystem::PutChar(CHAR_INFO* frame, int x, int y, wchar_t ch, WORD color) const
{
    if (x < 0 || x >= screenWidth_ || y < 0 || y >= screenHeight_)
        return;

    const int index = y * screenWidth_ + x;
    frame[index].Char.UnicodeChar = ch;
    frame[index].Attributes = color;
}

void RenderSystem::PutText(CHAR_INFO* frame, int x, int y, const wchar_t* text, WORD color) const
{
    if (text == nullptr)
        return;

    int offset = 0;
    while (text[offset] != L'\0')
    {
        PutChar(frame, x + offset, y, text[offset], color);
        ++offset;
    }
}

const wchar_t* RenderSystem::StateText(GameState state) const
{
    switch (state)
    {
    case GameState::Menu:
        return L"菜单";
    case GameState::Running:
        return L"运行中";
    case GameState::Paused:
        return L"暂停";
    case GameState::GameOver:
        return L"游戏结束";
    case GameState::Exit:
        return L"退出";
    default:
        return L"未知";
    }
}

const wchar_t* RenderSystem::SpeedText(SpeedLevel speed) const
{
    switch (speed)
    {
    case SpeedLevel::Low:
        return L"低";
    case SpeedLevel::Medium:
        return L"中";
    case SpeedLevel::High:
        return L"高";
    default:
        return L"未知";
    }
}

#endif
