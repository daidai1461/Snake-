#ifndef SNAKEGAME_SYSTEMS_TIMESYSTEM_CPP_INCLUDED
#define SNAKEGAME_SYSTEMS_TIMESYSTEM_CPP_INCLUDED

#include <chrono>

enum class SpeedLevel
{
    Low = 0,
    Medium,
    High
};

class TimeSystem
{
public:
    TimeSystem();

    void Reset();
    void SetSpeedLevel(SpeedLevel level);
    SpeedLevel GetSpeedLevel() const;

    void UpdateDynamicTickByScore(int score);
    int ConsumeAvailableTicks(int maxTicksPerFrame);

private:
    std::chrono::milliseconds BaseTickForLevel(SpeedLevel level) const;

    SpeedLevel speedLevel_;
    std::chrono::steady_clock::time_point lastTimePoint_;
    std::chrono::milliseconds accumulator_;
    std::chrono::milliseconds tickInterval_;
};

TimeSystem::TimeSystem()
    : speedLevel_(SpeedLevel::Medium),
      lastTimePoint_(std::chrono::steady_clock::now()),
      accumulator_(0),
      tickInterval_(BaseTickForLevel(speedLevel_))
{
}

void TimeSystem::Reset()
{
    lastTimePoint_ = std::chrono::steady_clock::now();
    accumulator_ = std::chrono::milliseconds(0);
    tickInterval_ = BaseTickForLevel(speedLevel_);
}

void TimeSystem::SetSpeedLevel(SpeedLevel level)
{
    speedLevel_ = level;
    tickInterval_ = BaseTickForLevel(speedLevel_);
    lastTimePoint_ = std::chrono::steady_clock::now();
    accumulator_ = std::chrono::milliseconds(0);
}

SpeedLevel TimeSystem::GetSpeedLevel() const
{
    return speedLevel_;
}

void TimeSystem::UpdateDynamicTickByScore(int score)
{
    std::chrono::milliseconds base = BaseTickForLevel(speedLevel_);
    const int reduction = (score / 50) * 10;
    int candidate = static_cast<int>(base.count()) - reduction;
    if (candidate < 20)
        candidate = 20;

    tickInterval_ = std::chrono::milliseconds(candidate);
}

int TimeSystem::ConsumeAvailableTicks(int maxTicksPerFrame)
{
    const auto now = std::chrono::steady_clock::now();
    accumulator_ += std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimePoint_);
    lastTimePoint_ = now;

    int ticks = 0;
    while (accumulator_ >= tickInterval_ && ticks < maxTicksPerFrame)
    {
        accumulator_ -= tickInterval_;
        ++ticks;
    }
    return ticks;
}

std::chrono::milliseconds TimeSystem::BaseTickForLevel(SpeedLevel level) const
{
    switch (level)
    {
    case SpeedLevel::Low:
        return std::chrono::milliseconds(60);
    case SpeedLevel::Medium:
        return std::chrono::milliseconds(40);
    case SpeedLevel::High:
        return std::chrono::milliseconds(30);
    default:
        return std::chrono::milliseconds(40);
    }
}

#endif
