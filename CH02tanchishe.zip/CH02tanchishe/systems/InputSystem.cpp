#ifndef SNAKEGAME_SYSTEMS_INPUTSYSTEM_CPP_INCLUDED
#define SNAKEGAME_SYSTEMS_INPUTSYSTEM_CPP_INCLUDED

#include "gameplay/Snake.cpp"
#include "systems/TimeSystem.cpp"

struct InputFrame
{
    bool requestStart = false;
    bool requestTogglePause = false;
    bool requestSave = false;
    bool requestLoad = false;
    bool requestExit = false;
    bool hasSpeedLevel = false;
    SpeedLevel speedLevel = SpeedLevel::Medium;

    bool hasDirection = false;
    Direction direction = Direction::Stop;
};

class InputSystem
{
public:
    InputFrame Collect(Direction currentDirection) const;

private:
    bool IsOpposite(Direction first, Direction second) const;
};

#include <conio.h>

InputFrame InputSystem::Collect(Direction currentDirection) const
{
    InputFrame frame;
    frame.direction = currentDirection;

    while (_kbhit())
    {
        const int ch = _getch();

        switch (ch)
        {
        case 'a':
        case 'A':
        {
            const Direction candidate = Direction::Left;
            if (!IsOpposite(candidate, currentDirection))
            {
                frame.hasDirection = true;
                frame.direction = candidate;
                frame.requestStart = true;
            }
            break;
        }
        case 'd':
        case 'D':
        {
            const Direction candidate = Direction::Right;
            if (!IsOpposite(candidate, currentDirection))
            {
                frame.hasDirection = true;
                frame.direction = candidate;
                frame.requestStart = true;
            }
            break;
        }
        case 'w':
        case 'W':
        {
            const Direction candidate = Direction::Up;
            if (!IsOpposite(candidate, currentDirection))
            {
                frame.hasDirection = true;
                frame.direction = candidate;
                frame.requestStart = true;
            }
            break;
        }
        case 's':
        case 'S':
        {
            const Direction candidate = Direction::Down;
            if (!IsOpposite(candidate, currentDirection))
            {
                frame.hasDirection = true;
                frame.direction = candidate;
                frame.requestStart = true;
            }
            break;
        }
        case ' ':
        case 13:
            frame.requestStart = true;
            break;
        case '1':
            frame.hasSpeedLevel = true;
            frame.speedLevel = SpeedLevel::Low;
            break;
        case '2':
            frame.hasSpeedLevel = true;
            frame.speedLevel = SpeedLevel::Medium;
            break;
        case '3':
            frame.hasSpeedLevel = true;
            frame.speedLevel = SpeedLevel::High;
            break;
        case 'p':
        case 'P':
            frame.requestTogglePause = true;
            break;
        case 'k':
        case 'K':
            frame.requestSave = true;
            break;
        case 'l':
        case 'L':
            frame.requestLoad = true;
            break;
        case 'x':
        case 'X':
            frame.requestExit = true;
            break;
        default:
            break;
        }
    }

    return frame;
}

bool InputSystem::IsOpposite(Direction first, Direction second) const
{
    if (first == Direction::Left && second == Direction::Right)
        return true;
    if (first == Direction::Right && second == Direction::Left)
        return true;
    if (first == Direction::Up && second == Direction::Down)
        return true;
    if (first == Direction::Down && second == Direction::Up)
        return true;
    return false;
}

#endif
