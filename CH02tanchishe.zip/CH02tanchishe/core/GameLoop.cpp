#ifndef SNAKEGAME_CORE_GAMELOOP_CPP_INCLUDED
#define SNAKEGAME_CORE_GAMELOOP_CPP_INCLUDED

#include "core/StateMachine.cpp"
#include "gameplay/Food.cpp"
#include "gameplay/Snake.cpp"
#include "persistence/SaveSystem.cpp"
#include "systems/InputSystem.cpp"
#include "systems/RenderSystem.cpp"
#include "systems/TimeSystem.cpp"

class GameLoop
{
public:
    GameLoop(int width, int height);
    void Run();

private:
    void ProcessInput();
    void Update();
    void UpdateOneTick();
    void Render();

    void ResetRound();
    void SaveCurrentGame() const;
    void TryLoadGame();

    bool IsPointInBounds(const Point& point) const;

    int width_;
    int height_;
    int score_;
    int highScore_;

    Snake snake_;
    Food food_;

    StateMachine stateMachine_;
    InputSystem inputSystem_;
    TimeSystem timeSystem_;
    RenderSystem renderSystem_;
    SaveSystem saveSystem_;
};

#include <cstdlib>
#include <ctime>
#include <vector>

GameLoop::GameLoop(int width, int height)
    : width_(width),
      height_(height),
      score_(0),
      highScore_(0),
      snake_(width / 2, height / 2),
      renderSystem_(width, height),
      saveSystem_("highscore.dat", "game_save.txt")
{
    timeSystem_.SetSpeedLevel(SpeedLevel::Medium);
}

void GameLoop::Run()
{
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    if (!renderSystem_.Initialize())
        return;

    highScore_ = saveSystem_.LoadHighScore();
    ResetRound();

    while (stateMachine_.GetState() != GameState::Exit)
    {
        ProcessInput();
        Update();
        Render();
    }

    if (score_ > highScore_)
    {
        highScore_ = score_;
        saveSystem_.SaveHighScore(highScore_);
    }
}

void GameLoop::ProcessInput()
{
    const InputFrame input = inputSystem_.Collect(snake_.GetDirection());

    if (input.requestExit)
    {
        stateMachine_.TransitionTo(GameState::Exit);
        return;
    }

    if (input.requestSave)
        SaveCurrentGame();

    if (input.requestLoad)
        TryLoadGame();

    const GameState currentState = stateMachine_.GetState();

    if (input.requestTogglePause)
    {
        if (currentState == GameState::Running)
            stateMachine_.TransitionTo(GameState::Paused);
        else if (currentState == GameState::Paused)
        {
            stateMachine_.TransitionTo(GameState::Running);
            timeSystem_.Reset();
        }
    }

    if (currentState == GameState::Menu)
    {
        if (input.requestStart || input.hasDirection)
        {
            ResetRound();
            stateMachine_.TransitionTo(GameState::Running);
        }
    }
    else if (currentState == GameState::GameOver)
    {
        if (input.requestStart || input.hasDirection)
        {
            stateMachine_.TransitionTo(GameState::Menu);
            ResetRound();
            stateMachine_.TransitionTo(GameState::Running);
        }
    }

    if (stateMachine_.GetState() == GameState::Running && input.hasDirection)
        snake_.SetDirection(input.direction);

    if (input.hasSpeedLevel)
        timeSystem_.SetSpeedLevel(input.speedLevel);
}

void GameLoop::Update()
{
    if (stateMachine_.GetState() != GameState::Running)
        return;

    const int ticks = timeSystem_.ConsumeAvailableTicks(30);
    for (int i = 0; i < ticks; ++i)
    {
        UpdateOneTick();
        if (stateMachine_.GetState() != GameState::Running)
            break;
    }
}

void GameLoop::UpdateOneTick()
{
    snake_.Move();

    if (snake_.GetDirection() == Direction::Stop)
        return;

    const Point& head = snake_.GetHead();
    if (head.x < 0 || head.x >= width_ || head.y < 0 || head.y >= height_)
    {
        stateMachine_.TransitionTo(GameState::GameOver);
        return;
    }

    if (snake_.CheckSelfCollision())
    {
        stateMachine_.TransitionTo(GameState::GameOver);
        return;
    }

    if (head == food_.GetPosition())
    {
        score_ += 10;
        snake_.Grow();
        if (score_ > highScore_)
            highScore_ = score_;

        food_.SpawnRandom(width_, height_, snake_);
    }
}

void GameLoop::Render()
{
    RenderData data;
    data.boardWidth = width_;
    data.boardHeight = height_;
    data.score = score_;
    data.highScore = highScore_;
    data.state = stateMachine_.GetState();
    data.speedLevel = timeSystem_.GetSpeedLevel();
    data.snake = &snake_;
    data.food = &food_;

    renderSystem_.Render(data);
}

void GameLoop::ResetRound()
{
    score_ = 0;
    snake_.Reset(width_ / 2, height_ / 2);
    food_.SpawnRandom(width_, height_, snake_);
    timeSystem_.Reset();
}

void GameLoop::SaveCurrentGame() const
{
    GameSnapshot snapshot;
    snapshot.width = width_;
    snapshot.height = height_;
    snapshot.score = score_;
    snapshot.highScore = highScore_;
    snapshot.state = stateMachine_.GetState();
    snapshot.speedLevel = timeSystem_.GetSpeedLevel();
    snapshot.direction = snake_.GetDirection();
    snapshot.food = food_.GetPosition();

    snapshot.snake.push_back(snake_.GetHead());
    for (const Point& segment : snake_.GetTail())
        snapshot.snake.push_back(segment);

    saveSystem_.SaveGame(snapshot);
}

void GameLoop::TryLoadGame()
{
    GameSnapshot snapshot;
    if (!saveSystem_.LoadGame(snapshot))
        return;

    if (snapshot.width != width_ || snapshot.height != height_)
        return;

    if (!IsPointInBounds(snapshot.food))
        return;

    if (snapshot.snake.empty())
        return;

    for (const Point& segment : snapshot.snake)
    {
        if (!IsPointInBounds(segment))
            return;
    }

    std::vector<Point> tail;
    if (snapshot.snake.size() > 1)
        tail.assign(snapshot.snake.begin() + 1, snapshot.snake.end());

    snake_.ApplyState(snapshot.snake.front(), tail, snapshot.direction);
    food_.SetPosition(snapshot.food);
    score_ = snapshot.score;
    highScore_ = snapshot.highScore;
    if (score_ > highScore_)
        highScore_ = score_;

    timeSystem_.SetSpeedLevel(snapshot.speedLevel);
    timeSystem_.Reset();

    stateMachine_.Reset();
    if (snapshot.state == GameState::Running)
    {
        stateMachine_.TransitionTo(GameState::Running);
    }
    else if (snapshot.state == GameState::Paused)
    {
        stateMachine_.TransitionTo(GameState::Running);
        stateMachine_.TransitionTo(GameState::Paused);
    }
    else if (snapshot.state == GameState::GameOver)
    {
        stateMachine_.TransitionTo(GameState::Running);
        stateMachine_.TransitionTo(GameState::GameOver);
    }
}

bool GameLoop::IsPointInBounds(const Point& point) const
{
    return point.x >= 0 && point.x < width_ && point.y >= 0 && point.y < height_;
}

#endif
