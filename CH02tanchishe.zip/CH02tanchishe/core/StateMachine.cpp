#ifndef SNAKEGAME_CORE_STATEMACHINE_CPP_INCLUDED
#define SNAKEGAME_CORE_STATEMACHINE_CPP_INCLUDED

enum class GameState
{
    Menu = 0,
    Running,
    Paused,
    GameOver,
    Exit
};

class StateMachine
{
public:
    StateMachine();

    GameState GetState() const;
    bool TransitionTo(GameState target);
    void Reset();

private:
    bool CanTransition(GameState from, GameState to) const;

    GameState state_;
};

StateMachine::StateMachine()
    : state_(GameState::Menu)
{
}

GameState StateMachine::GetState() const
{
    return state_;
}

bool StateMachine::TransitionTo(GameState target)
{
    if (target == state_)
        return true;

    if (!CanTransition(state_, target))
        return false;

    state_ = target;
    return true;
}

void StateMachine::Reset()
{
    state_ = GameState::Menu;
}

bool StateMachine::CanTransition(GameState from, GameState to) const
{
    switch (from)
    {
    case GameState::Menu:
        return to == GameState::Running || to == GameState::Exit;
    case GameState::Running:
        return to == GameState::Paused || to == GameState::GameOver || to == GameState::Exit;
    case GameState::Paused:
        return to == GameState::Running || to == GameState::Menu || to == GameState::Exit;
    case GameState::GameOver:
        return to == GameState::Menu || to == GameState::Exit;
    case GameState::Exit:
        return false;
    default:
        return false;
    }
}

#endif
