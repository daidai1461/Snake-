#ifndef SNAKEGAME_GAMEPLAY_FOOD_CPP_INCLUDED
#define SNAKEGAME_GAMEPLAY_FOOD_CPP_INCLUDED

#include "gameplay/Snake.cpp"

class Food
{
public:
    Food();

    const Point& GetPosition() const;
    void SetPosition(const Point& position);
    void SpawnRandom(int width, int height, const Snake& snake);

private:
    Point position_;
};

#include <cstdlib>

Food::Food()
{
    position_ = { 1, 1 };
}

const Point& Food::GetPosition() const
{
    return position_;
}

void Food::SetPosition(const Point& position)
{
    position_ = position;
}

void Food::SpawnRandom(int width, int height, const Snake& snake)
{
    if (width <= 0 || height <= 0)
    {
        position_ = { 0, 0 };
        return;
    }

    int marginX = width / 4;
    int marginY = height / 4;

    if (marginX < 1)
        marginX = 1;
    if (marginY < 1)
        marginY = 1;

    int minX = marginX;
    int maxX = width - marginX - 1;
    int minY = marginY;
    int maxY = height - marginY - 1;

    if (minX > maxX)
    {
        minX = 0;
        maxX = width - 1;
    }
    if (minY > maxY)
    {
        minY = 0;
        maxY = height - 1;
    }

    for (int i = 0; i < 120; ++i)
    {
        position_.x = minX + (std::rand() % (maxX - minX + 1));
        position_.y = minY + (std::rand() % (maxY - minY + 1));
        if (!snake.IsOccupying(position_.x, position_.y))
            return;
    }

    for (int i = 0; i < 300; ++i)
    {
        position_.x = std::rand() % width;
        position_.y = std::rand() % height;
        if (!snake.IsOccupying(position_.x, position_.y))
            return;
    }
}

#endif
