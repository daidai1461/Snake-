#ifndef SNAKEGAME_GAMEPLAY_SNAKE_CPP_INCLUDED
#define SNAKEGAME_GAMEPLAY_SNAKE_CPP_INCLUDED

#include <vector>

enum class Direction
{
    Stop = 0,
    Left,
    Right,
    Up,
    Down
};

struct Point
{
    int x;
    int y;

    bool operator==(const Point& other) const
    {
        return x == other.x && y == other.y;
    }
};

class Snake
{
public:
    Snake(int startX, int startY);

    void Reset(int startX, int startY);
    void SetDirection(Direction newDirection);
    Direction GetDirection() const;

    const Point& GetHead() const;
    const std::vector<Point>& GetTail() const;
    void ApplyState(const Point& head, const std::vector<Point>& tail, Direction direction);

    void Move();
    void Grow();

    bool IsOccupying(int x, int y) const;
    bool CheckSelfCollision() const;

private:
    Point head_;
    std::vector<Point> tail_;
    Direction direction_;
};

Snake::Snake(int startX, int startY)
{
    Reset(startX, startY);
}

void Snake::Reset(int startX, int startY)
{
    head_ = { startX, startY };
    tail_.clear();
    direction_ = Direction::Stop;
}

void Snake::SetDirection(Direction newDirection)
{
    direction_ = newDirection;
}

Direction Snake::GetDirection() const
{
    return direction_;
}

const Point& Snake::GetHead() const
{
    return head_;
}

const std::vector<Point>& Snake::GetTail() const
{
    return tail_;
}

void Snake::ApplyState(const Point& head, const std::vector<Point>& tail, Direction direction)
{
    head_ = head;
    tail_ = tail;
    direction_ = direction;
}

void Snake::Move()
{
    if (direction_ == Direction::Stop)
        return;

    Point previousHead = head_;
    if (!tail_.empty())
    {
        for (int i = static_cast<int>(tail_.size()) - 1; i > 0; --i)
            tail_[i] = tail_[i - 1];
        tail_[0] = previousHead;
    }

    switch (direction_)
    {
    case Direction::Left:
        --head_.x;
        break;
    case Direction::Right:
        ++head_.x;
        break;
    case Direction::Up:
        --head_.y;
        break;
    case Direction::Down:
        ++head_.y;
        break;
    default:
        break;
    }
}

void Snake::Grow()
{
    if (tail_.empty())
        tail_.push_back(head_);
    else
        tail_.push_back(tail_.back());
}

bool Snake::IsOccupying(int x, int y) const
{
    if (head_.x == x && head_.y == y)
        return true;

    for (const Point& segment : tail_)
    {
        if (segment.x == x && segment.y == y)
            return true;
    }

    return false;
}

bool Snake::CheckSelfCollision() const
{
    for (const Point& segment : tail_)
    {
        if (segment == head_)
            return true;
    }
    return false;
}

#endif
